import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const viewport: Viewport = {
  themeColor: "#ea580c",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Shopnexa",
  },
};

export const metadata: Metadata = {
  title: "Shopnexa - @www.shopnexa.com",
  description: "Shop the latest products at unbeatable prices. Browse electronics, fashion, home & furniture, and more with fast delivery and easy returns.",
  keywords: ["Shopnexa", "e-commerce", "online shopping", "deals", "fashion", "electronics"],
  authors: [{ name: "Aman Kumar" }],
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Shopnexa",
  },
  icons: {
    icon: "/icon.svg",
    apple: "/icons/icon-152x152.png",
  },
  openGraph: {
    type: "website",
    title: "Shopnexa - @www.shopnexa.com",
    description: "Your one-stop destination for everything you need.",
    siteName: "Shopnexa",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icons/icon-152x152.png" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="Shopnexa" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
