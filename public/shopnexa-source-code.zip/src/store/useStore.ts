import { create } from 'zustand';
import type { 
  Product, CartItem, WishlistItem, User, UserRole,
  PageView, FilterState, Order, Notification, Banner
} from '@/types';
import { products as seedProducts, categories as seedCategories, banners as seedBanners } from '@/data/seed-data';

interface AppState {
  // Navigation
  currentPage: PageView;
  previousPage: PageView | null;
  selectedProductId: string | null;
  selectedOrderId: string | null;
  navigateTo: (page: PageView) => void;
  goToProduct: (productId: string) => void;
  goToOrder: (orderId: string) => void;
  goBack: () => void;

  // Products
  products: Product[];
  categories: typeof seedCategories;
  banners: Banner[];
  filters: FilterState;
  setFilters: (filters: Partial<FilterState>) => void;
  resetFilters: () => void;
  getFilteredProducts: () => Product[];
  updateProductStock: (productId: string, stock: number) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  editProduct: (productId: string, data: Partial<Product>) => void;
  deleteUser: (userId: string) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartMRPTotal: () => number;
  getCartCount: () => number;
  
  // Wishlist
  wishlist: WishlistItem[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  
  // Auth
  user: User | null;
  isAuthenticated: boolean;
  registeredUsers: Array<User & { password: string }>;
  authError: string;
  login: (email: string, password: string) => string | null;
  register: (name: string, email: string, password: string, role?: UserRole, storeName?: string) => string | null;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  
  // Orders
  orders: Order[];
  placeOrder: (order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) => string;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  deleteOrder: (orderId: string) => void;
  togglePaymentStatus: (orderId: string, paymentStatus: Order['paymentStatus']) => void;
  
  // Coupons
  appliedCoupon: string | null;
  couponDiscount: number;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  
  // Notifications
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'read' | 'createdAt'>) => void;
  markNotificationRead: (id: string) => void;
  getUnreadCount: () => number;
  
  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchSuggestions: string[];
  
  // UI State
  showCartDrawer: boolean;
  setShowCartDrawer: (show: boolean) => void;
  showMobileMenu: boolean;
  setShowMobileMenu: (show: boolean) => void;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  authMode: 'login' | 'register';
  setAuthMode: (mode: 'login' | 'register') => void;
}

const defaultFilters: FilterState = {
  search: '',
  categoryId: '',
  minPrice: 0,
  maxPrice: 100000,
  minRating: 0,
  brand: '',
  sortBy: 'relevance',
  inStock: false,
};

export const useStore = create<AppState>((set, get) => ({
  // Navigation
  currentPage: 'home',
  previousPage: null,
  selectedProductId: null,
  selectedOrderId: null,
  
  navigateTo: (page) => set((state) => ({ 
    previousPage: state.currentPage, 
    currentPage: page 
  })),
  
  goToProduct: (productId) => set({ 
    previousPage: get().currentPage, 
    currentPage: 'product-detail', 
    selectedProductId: productId 
  }),
  
  goToOrder: (orderId) => set({ 
    previousPage: get().currentPage, 
    currentPage: 'order-detail', 
    selectedOrderId: orderId 
  }),
  
  goBack: () => set((state) => ({ 
    currentPage: state.previousPage || 'home',
    previousPage: null 
  })),
  
  // Products
  products: seedProducts,
  categories: seedCategories,
  banners: seedBanners,
  filters: defaultFilters,
  
  setFilters: (filters) => set((state) => ({ 
    filters: { ...state.filters, ...filters } 
  })),
  
  resetFilters: () => set({ filters: defaultFilters }),
  
  getFilteredProducts: () => {
    const { products, filters } = get();
    let filtered = [...products];
    
    if (filters.search) {
      const q = filters.search.toLowerCase();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.description.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    
    if (filters.categoryId) {
      // categoryId filter can be either a slug or an id — resolve slug → id
      const cat = get().categories.find(c => c.slug === filters.categoryId);
      const catId = cat ? cat.id : filters.categoryId;
      filtered = filtered.filter(p => p.categoryId === catId);
    }
    
    if (filters.brand) {
      filtered = filtered.filter(p => p.brand === filters.brand);
    }
    
    filtered = filtered.filter(p => p.price >= filters.minPrice && p.price <= filters.maxPrice);
    
    if (filters.minRating > 0) {
      filtered = filtered.filter(p => p.rating >= filters.minRating);
    }
    
    if (filters.inStock) {
      filtered = filtered.filter(p => p.stock > 0);
    }
    
    switch (filters.sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'popularity':
        filtered.sort((a, b) => b.sold - a.sold);
        break;
      case 'newest':
        filtered.sort((a, b) => (b.id > a.id ? 1 : -1));
        break;
    }
    
    return filtered;
  },

  updateProductStock: (productId, stock) => set((state) => ({
    products: state.products.map(p => p.id === productId ? { ...p, stock: Math.max(0, stock) } : p),
  })),

  addProduct: (product) => set((state) => ({
    products: [product, ...state.products],
  })),

  deleteProduct: (productId) => set((state) => ({
    products: state.products.filter(p => p.id !== productId),
  })),

  editProduct: (productId, data) => set((state) => ({
    products: state.products.map(p => p.id === productId ? { ...p, ...data } : p),
  })),

  deleteUser: (userId) => set((state) => ({
    registeredUsers: state.registeredUsers.filter(u => u.id !== userId),
  })),
  
  // Cart
  cart: [],
  
  addToCart: (product, quantity = 1) => set((state) => {
    const existing = state.cart.find(item => item.product.id === product.id);
    if (existing) {
      return {
        cart: state.cart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock) }
            : item
        ),
      };
    }
    return { cart: [...state.cart, { product, quantity }] };
  }),
  
  removeFromCart: (productId) => set((state) => ({
    cart: state.cart.filter(item => item.product.id !== productId),
  })),
  
  updateCartQuantity: (productId, quantity) => set((state) => ({
    cart: quantity <= 0
      ? state.cart.filter(item => item.product.id !== productId)
      : state.cart.map(item =>
          item.product.id === productId ? { ...item, quantity } : item
        ),
  })),
  
  clearCart: () => set({ cart: [], appliedCoupon: null, couponDiscount: 0 }),
  
  getCartTotal: () => {
    const { cart, couponDiscount } = get();
    const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    return Math.max(0, total - couponDiscount);
  },
  
  getCartMRPTotal: () => {
    return get().cart.reduce((sum, item) => sum + item.product.mrp * item.quantity, 0);
  },
  
  getCartCount: () => {
    return get().cart.reduce((sum, item) => sum + item.quantity, 0);
  },
  
  // Wishlist
  wishlist: [],
  
  addToWishlist: (product) => set((state) => {
    if (state.wishlist.find(item => item.product.id === product.id)) return state;
    return { wishlist: [...state.wishlist, { product, addedAt: new Date().toISOString() }] };
  }),
  
  removeFromWishlist: (productId) => set((state) => ({
    wishlist: state.wishlist.filter(item => item.product.id !== productId),
  })),
  
  isInWishlist: (productId) => {
    return get().wishlist.some(item => item.product.id === productId);
  },
  
  // Auth
  user: null,
  isAuthenticated: false,
  authError: '',
  
  registeredUsers: [
    // 👤 Customer Account - Aman Kumar
    {
      id: 'customer_aman',
      name: 'Aman Kumar',
      email: 'cswithaman91customer@shopnexa.com',
      role: 'customer',
      avatar: '',
      phone: '9117196506',
      address: '98, 04 Noorsarai Street, Noorsarai',
      city: 'BiharSharif',
      state: 'Bihar',
      pincode: '803113',
      password: 'AMAN@2026',
      createdAt: '2024-06-15T10:30:00.000Z',
    },
    // 🏪 Seller Account - Aman's Store
    {
      id: 'seller_aman',
      name: "Aman's Store",
      email: 'cswithaman91seller@shopnexa.com',
      role: 'seller',
      avatar: '',
      phone: '9117196506',
      address: '98, 04 Noorsarai Street, Noorsarai',
      city: 'BiharSharif',
      state: 'Bihar',
      pincode: '803113',
      sellerId: 'seller1',
      storeName: "Aman's Store",
      password: 'AMAN@2026',
      createdAt: '2024-06-15T10:35:00.000Z',
    },
    // 🛠️ Admin Account - Platform Owner
    {
      id: 'admin_aman',
      name: 'Platform Owner Aman Kumar',
      email: 'cswithaman91admin@shopnexa.com',
      role: 'admin',
      avatar: '',
      phone: '9117196506',
      address: '98, 04 Noorsarai Street, Noorsarai',
      city: 'BiharSharif',
      state: 'Bihar',
      pincode: '803113',
      sellerId: 'admin1',
      storeName: 'Shopnexa Official',
      password: 'AMAN@2026',
      createdAt: '2024-01-01T00:00:00.000Z',
    },
    // 👤 Demo Customer - Priya
    { id: 'customer_priya', name: 'Priya Sharma', email: 'priya@example.com', role: 'customer', avatar: '', phone: '9876543210', address: 'MG Road, Andheri', city: 'Mumbai', state: 'Maharashtra', pincode: '400058', password: 'pass', createdAt: '2024-08-20T10:30:00.000Z' },
    // 👤 Demo Customer - Rahul
    { id: 'customer_rahul', name: 'Rahul Verma', email: 'rahul@example.com', role: 'customer', avatar: '', phone: '8765432109', address: 'Sector 18, Noida', city: 'Noida', state: 'Uttar Pradesh', pincode: '201301', password: 'pass', createdAt: '2024-09-10T15:00:00.000Z' },
    // 👤 Demo Customer - Sneha
    { id: 'customer_sneha', name: 'Sneha Gupta', email: 'sneha@example.com', role: 'customer', avatar: '', phone: '7654321098', address: 'Jubilee Hills', city: 'Hyderabad', state: 'Telangana', pincode: '500033', password: 'pass', createdAt: '2024-10-05T09:00:00.000Z' },
    // 👤 Demo Customer - Amit
    { id: 'customer_amit', name: 'Amit Patel', email: 'amit@example.com', role: 'customer', avatar: '', phone: '7777777777', address: 'CG Road', city: 'Ahmedabad', state: 'Gujarat', pincode: '380006', password: 'pass', createdAt: '2024-11-01T08:00:00.000Z' },
    // 🏪 Demo Seller - TechWorld
    { id: 'seller_techworld', name: 'TechWorld Store', email: 'techworld@example.com', role: 'seller', avatar: '', phone: '9999999999', address: 'SP Infocity', city: 'Hyderabad', state: 'Telangana', pincode: '500081', sellerId: 'seller2', storeName: 'TechWorld', password: 'pass', createdAt: '2024-03-15T11:00:00.000Z' },
    // 🏪 Demo Seller - FashionHub
    { id: 'seller_fashionhub', name: 'Fashion Hub', email: 'fashionhub@example.com', role: 'seller', avatar: '', phone: '8888888888', address: 'Connaught Place', city: 'New Delhi', state: 'Delhi', pincode: '110001', sellerId: 'seller3', storeName: 'Fashion Hub', password: 'pass', createdAt: '2024-05-22T14:30:00.000Z' },
    // 🏪 Demo Seller - HomeDecor Plus
    { id: 'seller_homedecor', name: 'HomeDecor Plus', email: 'homedecor@example.com', role: 'seller', avatar: '', phone: '6666666666', address: 'Banjara Hills', city: 'Hyderabad', state: 'Telangana', pincode: '500034', sellerId: 'seller4', storeName: 'HomeDecor Plus', password: 'pass', createdAt: '2024-07-10T12:00:00.000Z' },
  ],

  login: (email, password) => {
    const userRecord = get().registeredUsers.find(
      u => u.email.toLowerCase() === email.toLowerCase().trim()
    );

    if (!userRecord) {
      set({ authError: 'No account found with this email. Please register first.' });
      return 'No account found';
    }

    if (userRecord.password !== password) {
      set({ authError: 'Wrong password. Please try again.' });
      return 'Wrong password';
    }

    const { password: _pw, ...userData } = userRecord;
    set({ user: userData, isAuthenticated: true, showAuthModal: false, authError: '' });
    get().addNotification({
      title: 'Welcome back!',
      message: 'You\'ve logged in as ' + userData.name + (userData.role === 'seller' ? ' (Seller)' : userData.role === 'admin' ? ' (Admin)' : ''),
      type: 'system',
    });
    return null;
  },

  register: (name, email, password, role, storeName) => {
    const trimmedEmail = email.toLowerCase().trim();

    // Check duplicate email
    const exists = get().registeredUsers.find(
      u => u.email.toLowerCase() === trimmedEmail
    );
    if (exists) {
      set({ authError: 'An account with this email already exists. Please login instead.' });
      return 'Email already registered';
    }

    // Validate password length
    if (password.length < 4) {
      set({ authError: 'Password must be at least 4 characters long.' });
      return 'Password too short';
    }

    const userId = 'user_' + Date.now();
    const userRole = role || 'customer';
    const isSeller = userRole === 'seller' || userRole === 'admin';

    const newRecord: User & { password: string } = {
      id: userId,
      name: name.trim(),
      email: trimmedEmail,
      role: userRole,
      avatar: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      pincode: '',
      sellerId: isSeller ? userId : undefined,
      storeName: isSeller ? (storeName || name.trim() + "'s Store") : undefined,
      password,
      createdAt: new Date().toISOString(),
    };

    set((state) => ({
      registeredUsers: [...state.registeredUsers, newRecord],
      authError: '',
    }));

    // Auto-login after register
    const { password: _pw, ...userData } = newRecord;
    set({ user: userData, isAuthenticated: true, showAuthModal: false });
    get().addNotification({
      title: isSeller ? 'Seller Account Created!' : 'Account created!',
      message: isSeller
        ? 'Welcome to Shopnexa, ' + name + '! Your store "' + newRecord.storeName + '" is ready. Start adding products!'
        : 'Welcome to Shopnexa, ' + name + '!',
      type: 'system',
    });
    return null;
  },

  logout: () => set({ user: null, isAuthenticated: false, authError: '' }),

  updateProfile: (data) => {
    const currentUser = get().user;
    if (!currentUser) return;
    const updatedUser: User = { ...currentUser, ...data };
    set((state) => ({
      user: updatedUser,
      registeredUsers: state.registeredUsers.map(u =>
        u.id === currentUser.id ? { ...u, ...data } : u
      ),
    }));
    get().addNotification({
      title: 'Profile Updated',
      message: 'Your profile has been saved successfully.',
      type: 'system',
    });
  },
  
  // Orders
  orders: [
    {
      id: 'ORD10001234',
      userId: 'customer_aman',
      items: [{ product: seedProducts[0], quantity: 1 }, { product: seedProducts[3], quantity: 2 }],
      totalAmount: 24998 + 3998 * 2,
      discount: 500,
      status: 'delivered',
      paymentMethod: 'upi',
      paymentStatus: 'paid',
      address: '98, Noorsarai Street', city: 'BiharSharif', state: 'Bihar', pincode: '803113', phone: '9117196506',
      trackingInfo: [
        { status: 'placed', message: 'Order placed successfully', timestamp: '2024-12-01T10:00:00Z', completed: true },
        { status: 'confirmed', message: 'Order confirmed by seller', timestamp: '2024-12-01T12:00:00Z', completed: true },
        { status: 'shipped', message: 'Package shipped via BlueDart', timestamp: '2024-12-02T09:00:00Z', completed: true },
        { status: 'delivered', message: 'Delivered to your address', timestamp: '2024-12-04T14:00:00Z', completed: true },
      ],
      createdAt: '2024-12-01T10:00:00.000Z', updatedAt: '2024-12-04T14:00:00.000Z',
    },
    {
      id: 'ORD10002345',
      userId: 'customer_priya',
      items: [{ product: seedProducts[1], quantity: 1 }],
      totalAmount: 44999,
      discount: 0,
      status: 'shipped',
      paymentMethod: 'visa',
      paymentStatus: 'paid',
      address: 'MG Road, Andheri', city: 'Mumbai', state: 'Maharashtra', pincode: '400058', phone: '9876543210',
      trackingInfo: [
        { status: 'placed', message: 'Order placed successfully', timestamp: '2025-01-10T08:00:00Z', completed: true },
        { status: 'confirmed', message: 'Order confirmed by seller', timestamp: '2025-01-10T10:00:00Z', completed: true },
        { status: 'shipped', message: 'Package shipped via DTDC', timestamp: '2025-01-11T09:00:00Z', completed: true },
      ],
      createdAt: '2025-01-10T08:00:00.000Z', updatedAt: '2025-01-11T09:00:00.000Z',
    },
    {
      id: 'ORD10003456',
      userId: 'customer_rahul',
      items: [{ product: seedProducts[5], quantity: 1 }, { product: seedProducts[7], quantity: 1 }],
      totalAmount: 12999 + 2499,
      discount: 200,
      status: 'confirmed',
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      address: 'Sector 18, Noida', city: 'Noida', state: 'Uttar Pradesh', pincode: '201301', phone: '8765432109',
      trackingInfo: [
        { status: 'placed', message: 'Order placed successfully', timestamp: '2025-01-15T14:00:00Z', completed: true },
        { status: 'confirmed', message: 'Order confirmed by seller', timestamp: '2025-01-15T16:00:00Z', completed: true },
      ],
      createdAt: '2025-01-15T14:00:00.000Z', updatedAt: '2025-01-15T16:00:00.000Z',
    },
    {
      id: 'ORD10004567',
      userId: 'customer_sneha',
      items: [{ product: seedProducts[2], quantity: 1 }],
      totalAmount: 8999,
      discount: 0,
      status: 'placed',
      paymentMethod: 'upi',
      paymentStatus: 'paid',
      address: 'Jubilee Hills', city: 'Hyderabad', state: 'Telangana', pincode: '500033', phone: '7654321098',
      trackingInfo: [
        { status: 'placed', message: 'Order placed successfully', timestamp: '2025-01-18T11:00:00Z', completed: true },
      ],
      createdAt: '2025-01-18T11:00:00.000Z', updatedAt: '2025-01-18T11:00:00.000Z',
    },
    {
      id: 'ORD10005678',
      userId: 'customer_amit',
      items: [{ product: seedProducts[10], quantity: 2 }, { product: seedProducts[12], quantity: 1 }],
      totalAmount: 1599 * 2 + 8999,
      discount: 300,
      status: 'cancelled',
      paymentMethod: 'mastercard',
      paymentStatus: 'paid',
      address: 'CG Road', city: 'Ahmedabad', state: 'Gujarat', pincode: '380006', phone: '7777777777',
      trackingInfo: [
        { status: 'placed', message: 'Order placed successfully', timestamp: '2025-01-05T09:00:00Z', completed: true },
      ],
      createdAt: '2025-01-05T09:00:00.000Z', updatedAt: '2025-01-06T10:00:00.000Z',
    },
    {
      id: 'ORD10006789',
      userId: 'customer_aman',
      items: [{ product: seedProducts[4], quantity: 1 }],
      totalAmount: 5999,
      discount: 0,
      status: 'rejected',
      paymentMethod: 'upi',
      paymentStatus: 'paid',
      address: '98, Noorsarai Street', city: 'BiharSharif', state: 'Bihar', pincode: '803113', phone: '9117196506',
      trackingInfo: [],
      createdAt: '2025-01-20T15:00:00.000Z', updatedAt: '2025-01-21T09:00:00.000Z',
    },
    {
      id: 'ORD10007890',
      userId: 'customer_priya',
      items: [{ product: seedProducts[8], quantity: 1 }, { product: seedProducts[11], quantity: 3 }],
      totalAmount: 3499 + 699 * 3,
      discount: 150,
      status: 'pending',
      paymentMethod: 'visa',
      paymentStatus: 'pending',
      address: 'MG Road, Andheri', city: 'Mumbai', state: 'Maharashtra', pincode: '400058', phone: '9876543210',
      trackingInfo: [],
      createdAt: '2025-01-25T16:30:00.000Z', updatedAt: '2025-01-25T16:30:00.000Z',
    },
    {
      id: 'ORD10008901',
      userId: 'customer_rahul',
      items: [{ product: seedProducts[6], quantity: 2 }],
      totalAmount: 7999 * 2,
      discount: 0,
      status: 'pending',
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      address: 'Sector 18, Noida', city: 'Noida', state: 'Uttar Pradesh', pincode: '201301', phone: '8765432109',
      trackingInfo: [],
      createdAt: '2025-01-26T09:00:00.000Z', updatedAt: '2025-01-26T09:00:00.000Z',
    },
  ],
  
  placeOrder: (order) => {
    const id = 'ORD' + Date.now().toString().slice(-8);
    const newOrder: Order = {
      ...order,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    set((state) => ({ orders: [newOrder, ...state.orders] }));
    
    get().addNotification({
      title: 'Order Placed!',
      message: `Order ${id} has been placed successfully`,
      type: 'order',
    });
    
    get().clearCart();
    return id;
  },
  
  updateOrderStatus: (orderId, status) => set((state) => ({
    orders: state.orders.map(o => o.id === orderId ? { ...o, status, updatedAt: new Date().toISOString() } : o),
  })),

  deleteOrder: (orderId) => set((state) => ({
    orders: state.orders.filter(o => o.id !== orderId),
  })),

  togglePaymentStatus: (orderId, paymentStatus) => set((state) => ({
    orders: state.orders.map(o => o.id === orderId ? { ...o, paymentStatus, updatedAt: new Date().toISOString() } : o),
  })),
  
  // Coupons
  appliedCoupon: null,
  couponDiscount: 0,
  
  applyCoupon: (code) => {
    const coupons: Record<string, { discount: number; minOrder: number; maxDiscount: number }> = {
      'SAVE10': { discount: 10, minOrder: 500, maxDiscount: 200 },
      'FLAT20': { discount: 20, minOrder: 1000, maxDiscount: 500 },
      'WELCOME': { discount: 15, minOrder: 0, maxDiscount: 300 },
      'MEGA50': { discount: 50, minOrder: 2000, maxDiscount: 1000 },
    };
    
    const coupon = coupons[code.toUpperCase()];
    if (!coupon) return false;
    
    const cartTotal = get().getCartTotal();
    if (cartTotal < coupon.minOrder) return false;
    
    const discount = Math.min((cartTotal * coupon.discount) / 100, coupon.maxDiscount);
    set({ appliedCoupon: code.toUpperCase(), couponDiscount: discount });
    return true;
  },
  
  removeCoupon: () => set({ appliedCoupon: null, couponDiscount: 0 }),
  
  // Notifications
  notifications: [
    {
      id: 'n1',
      title: 'Flash Sale Live!',
      message: 'Up to 70% off on electronics. Limited time offer!',
      type: 'offer',
      read: false,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'n2',
      title: 'Free Delivery Weekend',
      message: 'Enjoy free delivery on all orders this weekend',
      type: 'delivery',
      read: false,
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ],
  
  addNotification: (notification) => set((state) => ({
    notifications: [{
      id: 'n' + Date.now(),
      read: false,
      createdAt: new Date().toISOString(),
      ...notification,
    }, ...state.notifications],
  })),
  
  markNotificationRead: (id) => set((state) => ({
    notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n),
  })),
  
  getUnreadCount: () => get().notifications.filter(n => !n.read).length,
  
  // Search
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  searchSuggestions: [],
  
  // UI State
  showCartDrawer: false,
  setShowCartDrawer: (show) => set({ showCartDrawer: show }),
  showMobileMenu: false,
  setShowMobileMenu: (show) => set({ showMobileMenu: show }),
  showAuthModal: false,
  setShowAuthModal: (show) => set({ showAuthModal: show }),
  authMode: 'login',
  setAuthMode: (mode) => set({ authMode: mode }),
}));
