'use client';

import { useEffect, useState, useRef } from 'react';
import { X, Download, Smartphone } from 'lucide-react';

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<Event | null>(null);
  const [showBanner, setShowBanner] = useState(false);
  const installedRef = useRef(false);
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    // Check if already installed as PWA
    const standalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    if (standalone) {
      installedRef.current = true;
      return;
    }

    // Show install banner after 3 seconds (only once per session)
    const dismissed = sessionStorage.getItem('pwa-banner-dismissed');
    if (!dismissed) {
      const timer = setTimeout(() => setShowBanner(true), 3000);
      return () => clearTimeout(timer);
    }
  }, []);

  // Listen for the beforeinstallprompt event
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  // Listen for app installed event
  useEffect(() => {
    const handler = () => {
      installedRef.current = true;
      setShowBanner(false);
      setDeferredPrompt(null);
    };
    window.addEventListener('appinstalled', handler);
    return () => window.removeEventListener('appinstalled', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    (deferredPrompt as unknown as { prompt: () => Promise<void> }).prompt();
    await (deferredPrompt as unknown as { userChoice: Promise<{ outcome: string }> }).userChoice;
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowBanner(false);
    sessionStorage.setItem('pwa-banner-dismissed', 'true');
  };

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-20 left-3 right-3 sm:left-auto sm:right-4 sm:max-w-sm z-[70] animate-in slide-in-from-bottom duration-500">
      <div className="bg-white rounded-2xl shadow-2xl border p-4">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 via-rose-500 to-pink-600 flex items-center justify-center shrink-0 shadow-lg shadow-orange-500/20">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" />
              <line x1="3" y1="6" x2="21" y2="6" />
              <path d="M16 10a4 4 0 01-8 0" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg">
              <span>Shop</span><span className="bg-gradient-to-r from-orange-600 to-rose-500 bg-clip-text text-transparent">nexa</span>
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">Add to home screen for faster access &amp; app-like experience</p>
          </div>
          <button onClick={handleDismiss} className="p-1 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 shrink-0">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex items-center gap-2 mt-3">
          <button
            onClick={handleInstall}
            className="flex-1 flex items-center justify-center gap-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold py-2.5 rounded-xl transition-colors"
          >
            <Download className="h-4 w-4" />
            Install App
          </button>
          <button
            onClick={handleDismiss}
            className="text-xs text-muted-foreground hover:text-gray-700 px-3 py-2.5"
          >
            Not now
          </button>
        </div>
        <div className="flex items-center gap-2 mt-2 pt-2 border-t">
          <Smartphone className="h-3 w-3 text-gray-400" />
          <p className="text-[10px] text-gray-400">Works offline • No Play Store needed</p>
        </div>
      </div>
    </div>
  );
}
