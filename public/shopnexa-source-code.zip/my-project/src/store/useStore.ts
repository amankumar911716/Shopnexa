import { create } from 'zustand';
import type { 
  Product, CartItem, WishlistItem, User, UserRole,
  PageView, FilterState, Order, Notification, Banner
} from '@/types';
import { products as seedProducts, categories as seedCategories, banners as seedBanners } from '@/data/seed-data';

interface AppState {
  // Navigation
  currentPage: PageView;
  previousPage: PageView | null;
  selectedProductId: string | null;
  selectedOrderId: string | null;
  navigateTo: (page: PageView) => void;
  goToProduct: (productId: string) => void;
  goToOrder: (orderId: string) => void;
  goBack: () => void;

  // Products
  products: Product[];
  categories: typeof seedCategories;
  banners: Banner[];
  filters: FilterState;
  setFilters: (filters: Partial<FilterState>) => void;
  resetFilters: () => void;
  getFilteredProducts: () => Product[];
  updateProductStock: (productId: string, stock: number) => void;
  addProduct: (product: Product) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartMRPTotal: () => number;
  getCartCount: () => number;
  
  // Wishlist
  wishlist: WishlistItem[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  
  // Auth
  user: User | null;
  isAuthenticated: boolean;
  registeredUsers: Array<User & { password: string }>;
  authError: string;
  login: (email: string, password: string) => string | null;
  register: (name: string, email: string, password: string, role?: UserRole, storeName?: string) => string | null;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  
  // Orders
  orders: Order[];
  placeOrder: (order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) => string;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  
  // Coupons
  appliedCoupon: string | null;
  couponDiscount: number;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  
  // Notifications
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'read' | 'createdAt'>) => void;
  markNotificationRead: (id: string) => void;
  getUnreadCount: () => number;
  
  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchSuggestions: string[];
  
  // UI State
  showCartDrawer: boolean;
  setShowCartDrawer: (show: boolean) => void;
  showMobileMenu: boolean;
  setShowMobileMenu: (show: boolean) => void;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  authMode: 'login' | 'register';
  setAuthMode: (mode: 'login' | 'register') => void;
}

const defaultFilters: FilterState = {
  search: '',
  categoryId: '',
  minPrice: 0,
  maxPrice: 100000,
  minRating: 0,
  brand: '',
  sortBy: 'relevance',
  inStock: false,
};

export const useStore = create<AppState>((set, get) => ({
  // Navigation
  currentPage: 'home',
  previousPage: null,
  selectedProductId: null,
  selectedOrderId: null,
  
  navigateTo: (page) => set((state) => ({ 
    previousPage: state.currentPage, 
    currentPage: page 
  })),
  
  goToProduct: (productId) => set({ 
    previousPage: get().currentPage, 
    currentPage: 'product-detail', 
    selectedProductId: productId 
  }),
  
  goToOrder: (orderId) => set({ 
    previousPage: get().currentPage, 
    currentPage: 'order-detail', 
    selectedOrderId: orderId 
  }),
  
  goBack: () => set((state) => ({ 
    currentPage: state.previousPage || 'home',
    previousPage: null 
  })),
  
  // Products
  products: seedProducts,
  categories: seedCategories,
  banners: seedBanners,
  filters: defaultFilters,
  
  setFilters: (filters) => set((state) => ({ 
    filters: { ...state.filters, ...filters } 
  })),
  
  resetFilters: () => set({ filters: defaultFilters }),
  
  getFilteredProducts: () => {
    const { products, filters } = get();
    let filtered = [...products];
    
    if (filters.search) {
      const q = filters.search.toLowerCase();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.description.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    
    if (filters.categoryId) {
      // categoryId filter can be either a slug or an id — resolve slug → id
      const cat = get().categories.find(c => c.slug === filters.categoryId);
      const catId = cat ? cat.id : filters.categoryId;
      filtered = filtered.filter(p => p.categoryId === catId);
    }
    
    if (filters.brand) {
      filtered = filtered.filter(p => p.brand === filters.brand);
    }
    
    filtered = filtered.filter(p => p.price >= filters.minPrice && p.price <= filters.maxPrice);
    
    if (filters.minRating > 0) {
      filtered = filtered.filter(p => p.rating >= filters.minRating);
    }
    
    if (filters.inStock) {
      filtered = filtered.filter(p => p.stock > 0);
    }
    
    switch (filters.sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'popularity':
        filtered.sort((a, b) => b.sold - a.sold);
        break;
      case 'newest':
        filtered.sort((a, b) => (b.id > a.id ? 1 : -1));
        break;
    }
    
    return filtered;
  },

  updateProductStock: (productId, stock) => set((state) => ({
    products: state.products.map(p => p.id === productId ? { ...p, stock: Math.max(0, stock) } : p),
  })),

  addProduct: (product) => set((state) => ({
    products: [product, ...state.products],
  })),
  
  // Cart
  cart: [],
  
  addToCart: (product, quantity = 1) => set((state) => {
    const existing = state.cart.find(item => item.product.id === product.id);
    if (existing) {
      return {
        cart: state.cart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock) }
            : item
        ),
      };
    }
    return { cart: [...state.cart, { product, quantity }] };
  }),
  
  removeFromCart: (productId) => set((state) => ({
    cart: state.cart.filter(item => item.product.id !== productId),
  })),
  
  updateCartQuantity: (productId, quantity) => set((state) => ({
    cart: quantity <= 0
      ? state.cart.filter(item => item.product.id !== productId)
      : state.cart.map(item =>
          item.product.id === productId ? { ...item, quantity } : item
        ),
  })),
  
  clearCart: () => set({ cart: [], appliedCoupon: null, couponDiscount: 0 }),
  
  getCartTotal: () => {
    const { cart, couponDiscount } = get();
    const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    return Math.max(0, total - couponDiscount);
  },
  
  getCartMRPTotal: () => {
    return get().cart.reduce((sum, item) => sum + item.product.mrp * item.quantity, 0);
  },
  
  getCartCount: () => {
    return get().cart.reduce((sum, item) => sum + item.quantity, 0);
  },
  
  // Wishlist
  wishlist: [],
  
  addToWishlist: (product) => set((state) => {
    if (state.wishlist.find(item => item.product.id === product.id)) return state;
    return { wishlist: [...state.wishlist, { product, addedAt: new Date().toISOString() }] };
  }),
  
  removeFromWishlist: (productId) => set((state) => ({
    wishlist: state.wishlist.filter(item => item.product.id !== productId),
  })),
  
  isInWishlist: (productId) => {
    return get().wishlist.some(item => item.product.id === productId);
  },
  
  // Auth
  user: null,
  isAuthenticated: false,
  authError: '',
  
  registeredUsers: [
    // 👤 Customer Account - Aman Kumar
    {
      id: 'customer_aman',
      name: 'Aman Kumar',
      email: 'cswithaman91customer@shopnexa.com',
      role: 'customer',
      avatar: '',
      phone: '9117196506',
      address: '98, 04 Noorsarai Street, Noorsarai',
      city: 'BiharSharif',
      state: 'Bihar',
      pincode: '803113',
      password: 'AMAN@2026',
      createdAt: '2024-06-15T10:30:00.000Z',
    },
    // 🏪 Seller Account - Aman's Store
    {
      id: 'seller_aman',
      name: "Aman's Store",
      email: 'cswithaman91seller@shopnexa.com',
      role: 'seller',
      avatar: '',
      phone: '9117196506',
      address: '98, 04 Noorsarai Street, Noorsarai',
      city: 'BiharSharif',
      state: 'Bihar',
      pincode: '803113',
      sellerId: 'seller1',
      storeName: "Aman's Store",
      password: 'AMAN@2026',
      createdAt: '2024-06-15T10:35:00.000Z',
    },
    // 🛠️ Admin Account - Platform Owner
    {
      id: 'admin_aman',
      name: 'Platform Owner Aman Kumar',
      email: 'cswithaman91admin@shopnexa.com',
      role: 'admin',
      avatar: '',
      phone: '9117196506',
      address: '98, 04 Noorsarai Street, Noorsarai',
      city: 'BiharSharif',
      state: 'Bihar',
      pincode: '803113',
      sellerId: 'admin1',
      storeName: 'Shopnexa Official',
      password: 'AMAN@2026',
      createdAt: '2024-01-01T00:00:00.000Z',
    },
  ],

  login: (email, password) => {
    const userRecord = get().registeredUsers.find(
      u => u.email.toLowerCase() === email.toLowerCase().trim()
    );

    if (!userRecord) {
      set({ authError: 'No account found with this email. Please register first.' });
      return 'No account found';
    }

    if (userRecord.password !== password) {
      set({ authError: 'Wrong password. Please try again.' });
      return 'Wrong password';
    }

    const { password: _pw, ...userData } = userRecord;
    set({ user: userData, isAuthenticated: true, showAuthModal: false, authError: '' });
    get().addNotification({
      title: 'Welcome back!',
      message: 'You\'ve logged in as ' + userData.name + (userData.role === 'seller' ? ' (Seller)' : userData.role === 'admin' ? ' (Admin)' : ''),
      type: 'system',
    });
    return null;
  },

  register: (name, email, password, role, storeName) => {
    const trimmedEmail = email.toLowerCase().trim();

    // Check duplicate email
    const exists = get().registeredUsers.find(
      u => u.email.toLowerCase() === trimmedEmail
    );
    if (exists) {
      set({ authError: 'An account with this email already exists. Please login instead.' });
      return 'Email already registered';
    }

    // Validate password length
    if (password.length < 4) {
      set({ authError: 'Password must be at least 4 characters long.' });
      return 'Password too short';
    }

    const userId = 'user_' + Date.now();
    const userRole = role || 'customer';
    const isSeller = userRole === 'seller' || userRole === 'admin';

    const newRecord: User & { password: string } = {
      id: userId,
      name: name.trim(),
      email: trimmedEmail,
      role: userRole,
      avatar: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      pincode: '',
      sellerId: isSeller ? userId : undefined,
      storeName: isSeller ? (storeName || name.trim() + "'s Store") : undefined,
      password,
      createdAt: new Date().toISOString(),
    };

    set((state) => ({
      registeredUsers: [...state.registeredUsers, newRecord],
      authError: '',
    }));

    // Auto-login after register
    const { password: _pw, ...userData } = newRecord;
    set({ user: userData, isAuthenticated: true, showAuthModal: false });
    get().addNotification({
      title: isSeller ? 'Seller Account Created!' : 'Account created!',
      message: isSeller
        ? 'Welcome to Shopnexa, ' + name + '! Your store "' + newRecord.storeName + '" is ready. Start adding products!'
        : 'Welcome to Shopnexa, ' + name + '!',
      type: 'system',
    });
    return null;
  },

  logout: () => set({ user: null, isAuthenticated: false, authError: '' }),

  updateProfile: (data) => {
    const currentUser = get().user;
    if (!currentUser) return;
    const updatedUser: User = { ...currentUser, ...data };
    set((state) => ({
      user: updatedUser,
      registeredUsers: state.registeredUsers.map(u =>
        u.id === currentUser.id ? { ...u, ...data } : u
      ),
    }));
    get().addNotification({
      title: 'Profile Updated',
      message: 'Your profile has been saved successfully.',
      type: 'system',
    });
  },
  
  // Orders
  orders: [],
  
  placeOrder: (order) => {
    const id = 'ORD' + Date.now().toString().slice(-8);
    const newOrder: Order = {
      ...order,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    set((state) => ({ orders: [newOrder, ...state.orders] }));
    
    get().addNotification({
      title: 'Order Placed!',
      message: `Order ${id} has been placed successfully`,
      type: 'order',
    });
    
    get().clearCart();
    return id;
  },
  
  updateOrderStatus: (orderId, status) => set((state) => ({
    orders: state.orders.map(o => o.id === orderId ? { ...o, status, updatedAt: new Date().toISOString() } : o),
  })),
  
  // Coupons
  appliedCoupon: null,
  couponDiscount: 0,
  
  applyCoupon: (code) => {
    const coupons: Record<string, { discount: number; minOrder: number; maxDiscount: number }> = {
      'SAVE10': { discount: 10, minOrder: 500, maxDiscount: 200 },
      'FLAT20': { discount: 20, minOrder: 1000, maxDiscount: 500 },
      'WELCOME': { discount: 15, minOrder: 0, maxDiscount: 300 },
      'MEGA50': { discount: 50, minOrder: 2000, maxDiscount: 1000 },
    };
    
    const coupon = coupons[code.toUpperCase()];
    if (!coupon) return false;
    
    const cartTotal = get().getCartTotal();
    if (cartTotal < coupon.minOrder) return false;
    
    const discount = Math.min((cartTotal * coupon.discount) / 100, coupon.maxDiscount);
    set({ appliedCoupon: code.toUpperCase(), couponDiscount: discount });
    return true;
  },
  
  removeCoupon: () => set({ appliedCoupon: null, couponDiscount: 0 }),
  
  // Notifications
  notifications: [
    {
      id: 'n1',
      title: 'Flash Sale Live!',
      message: 'Up to 70% off on electronics. Limited time offer!',
      type: 'offer',
      read: false,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'n2',
      title: 'Free Delivery Weekend',
      message: 'Enjoy free delivery on all orders this weekend',
      type: 'delivery',
      read: false,
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ],
  
  addNotification: (notification) => set((state) => ({
    notifications: [{
      id: 'n' + Date.now(),
      read: false,
      createdAt: new Date().toISOString(),
      ...notification,
    }, ...state.notifications],
  })),
  
  markNotificationRead: (id) => set((state) => ({
    notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n),
  })),
  
  getUnreadCount: () => get().notifications.filter(n => !n.read).length,
  
  // Search
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  searchSuggestions: [],
  
  // UI State
  showCartDrawer: false,
  setShowCartDrawer: (show) => set({ showCartDrawer: show }),
  showMobileMenu: false,
  setShowMobileMenu: (show) => set({ showMobileMenu: show }),
  showAuthModal: false,
  setShowAuthModal: (show) => set({ showAuthModal: show }),
  authMode: 'login',
  setAuthMode: (mode) => set({ authMode: mode }),
}));
