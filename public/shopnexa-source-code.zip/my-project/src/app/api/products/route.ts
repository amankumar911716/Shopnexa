import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const brand = searchParams.get('brand');
    const sortBy = searchParams.get('sortBy') || 'relevance';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: any = {};
    if (category) where.categoryId = category;
    if (search) where.OR = [
      { name: { contains: search } },
      { description: { contains: search } },
      { brand: { contains: search } },
      { tags: { contains: search } },
    ];
    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = parseFloat(minPrice);
      if (maxPrice) where.price.lte = parseFloat(maxPrice);
    }
    if (brand) where.brand = brand;

    const orderBy: any = sortBy === 'price-low' ? { price: 'asc' }
      : sortBy === 'price-high' ? { price: 'desc' }
      : sortBy === 'rating' ? { rating: 'desc' }
      : sortBy === 'newest' ? { createdAt: 'desc' }
      : { sold: 'desc' };

    const [products, total] = await Promise.all([
      db.product.findMany({
        where,
        include: { category: { select: { name: true } } },
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.product.count({ where }),
    ]);

    return NextResponse.json({
      products: products.map(p => ({
        ...p,
        images: JSON.parse(p.images),
        specifications: JSON.parse(p.specifications),
        tags: JSON.parse(p.tags),
        categoryName: p.category.name,
      })),
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const product = await db.product.create({
      data: {
        name: body.name,
        slug: body.slug || body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        description: body.description || '',
        price: body.price,
        mrp: body.mrp || body.price,
        images: JSON.stringify(body.images || []),
        categoryId: body.categoryId,
        brand: body.brand || '',
        stock: body.stock || 0,
        specifications: JSON.stringify(body.specifications || {}),
        tags: JSON.stringify(body.tags || []),
        isFeatured: body.isFeatured || false,
        isTrending: body.isTrending || false,
        isFlashDeal: body.isFlashDeal || false,
        flashPrice: body.flashPrice,
        sellerId: body.sellerId || 'seller1',
      },
    });

    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 });
  }
}
