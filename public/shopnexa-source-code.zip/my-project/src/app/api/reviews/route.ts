import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const productId = searchParams.get('productId');

    const where: any = {};
    if (productId) where.productId = productId;

    const reviews = await db.review.findMany({
      where,
      include: { user: { select: { name: true, avatar: true } } },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(reviews.map(r => ({
      ...r,
      userName: r.user.name,
      userAvatar: r.user.avatar,
    })));
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch reviews' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const review = await db.review.create({
      data: {
        productId: body.productId,
        userId: body.userId,
        rating: body.rating,
        title: body.title || '',
        comment: body.comment || '',
        isVerified: body.isVerified || false,
      },
    });

    // Update product rating
    const reviews = await db.review.findMany({
      where: { productId: body.productId },
    });
    const avgRating = reviews.reduce((sum: number, r: any) => sum + r.rating, 0) / reviews.length;
    await db.product.update({
      where: { id: body.productId },
      data: { rating: avgRating, reviewCount: reviews.length },
    });

    return NextResponse.json(review, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create review' }, { status: 500 });
  }
}
