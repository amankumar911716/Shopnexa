import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    const where: any = {};
    if (userId) where.userId = userId;

    const orders = await db.order.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(
      orders.map(o => ({
        ...o,
        items: JSON.parse(o.items),
        trackingInfo: JSON.parse(o.trackingInfo),
      }))
    );
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const order = await db.order.create({
      data: {
        userId: body.userId,
        items: JSON.stringify(body.items),
        totalAmount: body.totalAmount,
        discount: body.discount || 0,
        status: body.status || 'placed',
        paymentMethod: body.paymentMethod || 'cod',
        address: body.address || '',
        city: body.city || '',
        state: body.state || '',
        pincode: body.pincode || '',
        phone: body.phone || '',
        trackingInfo: JSON.stringify(body.trackingInfo || []),
      },
    });
    return NextResponse.json(order, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    
    const updateData: any = {};
    if (data.status) updateData.status = data.status;
    if (data.trackingInfo) updateData.trackingInfo = JSON.stringify(data.trackingInfo);

    const order = await db.order.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json(order);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update order' }, { status: 500 });
  }
}
