'use client';

import { useStore } from '@/store/useStore';
import { Separator } from '@/components/ui/separator';

export function Footer() {
  const { categories, navigateTo, setFilters } = useStore();

  const handleCategoryClick = (slug: string) => {
    setFilters({ search: '', categoryId: slug });
    navigateTo('products');
  };

  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-lg flex items-center justify-center"><span className="text-white font-bold text-sm">S</span></div>
              <h3 className="text-xl font-bold text-white">Shop<span className="text-emerald-400">nexa</span></h3>
            </div>
            <p className="text-sm text-gray-400 mb-4">Your one-stop destination for everything you need. Shop the latest products at unbeatable prices with fast delivery.</p>
            <div className="flex gap-3">
              {['𝕏', 'f', 'in', '📷'].map((icon) => (
                <button key={icon} className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-xs hover:bg-emerald-600 transition-colors">{icon}</button>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              {[
                { label: 'Home', page: 'home' as const },
                { label: 'All Products', page: 'products' as const },
                { label: 'My Orders', page: 'orders' as const },
                { label: 'Wishlist', page: 'wishlist' as const },
                { label: 'Seller Dashboard', page: 'seller' as const },
              ].map((item) => (
                <li key={item.label}><button onClick={() => navigateTo(item.page)} className="hover:text-emerald-400 transition-colors">{item.label}</button></li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-semibold mb-4">Categories</h4>
            <ul className="space-y-2 text-sm">
              {categories.map((cat) => (
                <li key={cat.id}><button onClick={() => handleCategoryClick(cat.slug)} className="hover:text-emerald-400 transition-colors">{cat.name}</button></li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2"><span>📍</span><span>98, 04 Noorsarai Street, Noorsarai, BiharSharif, Nalanda, Bihar, INDIA - 803113</span></li>
              <li className="flex items-center gap-2"><span>📞</span><span>+91 - 911 719 6506</span></li>
              <li className="flex items-center gap-2"><span>✉️</span><span>cswithaman91@gmail.com</span></li>
            </ul>
            <div className="mt-4 pt-3 border-t border-gray-800">
              <p className="text-xs text-gray-400"><span className="text-emerald-400 font-semibold">Platform Owner:</span> Aman Kumar</p>
            </div>
            <div className="mt-4"><p className="text-xs text-gray-500">We accept</p>
              <div className="flex gap-2 mt-2">{['VISA', 'UPI', 'MC', 'COD'].map((p) => (<span key={p} className="px-2 py-1 bg-gray-800 rounded text-[10px] font-semibold">{p}</span>))}</div>
            </div>
          </div>
        </div>

        <Separator className="my-8 bg-gray-800" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <p>© 2025 Shopnexa. All rights reserved. Designed by <span className="text-emerald-400">Aman Kumar</span></p>
          <div className="flex gap-4">
            <button className="hover:text-gray-300">Privacy Policy</button>
            <button className="hover:text-gray-300">Terms of Service</button>
            <button className="hover:text-gray-300">Returns Policy</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
