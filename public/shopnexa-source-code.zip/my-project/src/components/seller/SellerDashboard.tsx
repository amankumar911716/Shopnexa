'use client';

import { useStore } from '@/store/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import {
  DollarSign, Package, TrendingUp, Eye, Edit, Plus,
  BarChart3, Upload, ShoppingBag, Star, ArrowUpRight, X, Check, Video, ImageIcon, Trash2
} from 'lucide-react';
import { useState } from 'react';
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { Product } from '@/types';

const salesData = [
  { month: 'Jan', sales: 45000 },
  { month: 'Feb', sales: 38000 },
  { month: 'Mar', sales: 62000 },
  { month: 'Apr', sales: 55000 },
  { month: 'May', sales: 71000 },
  { month: 'Jun', sales: 85000 },
];

const emptyForm = {
  name: '', price: '', mrp: '', stock: '', category: '', brand: '', description: '',
  images: [''],
  videos: [''],
};

export function SellerDashboard() {
  const { products, orders, goBack, goToProduct, updateProductStock, addProduct, categories, user, isAuthenticated } = useStore();
  const [toastMsg, setToastMsg] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editStock, setEditStock] = useState<number>(0);
  const [showAddForm, setShowAddForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Use the logged-in user's ID as the sellerId
  const currentSellerId = user?.sellerId || user?.id;
  const storeName = user?.storeName || user?.name || 'My Store';

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 3000);
  };

  const startEditStock = (productId: string, currentStock: number) => {
    setEditingId(productId);
    setEditStock(currentStock);
  };

  const saveStock = () => {
    if (editingId) {
      updateProductStock(editingId, editStock);
      showToast('Stock updated to ' + editStock + '!');
      setEditingId(null);
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditStock(0);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!form.name.trim()) errors.name = 'Product name is required';
    if (!form.price || Number(form.price) <= 0) errors.price = 'Valid price is required';
    if (!form.mrp || Number(form.mrp) <= 0) errors.mrp = 'Valid MRP is required';
    if (!form.stock || Number(form.stock) < 0) errors.stock = 'Valid stock is required';
    if (!form.category) errors.category = 'Select a category';
    if (!form.brand.trim()) errors.brand = 'Brand is required';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const addImageField = () => setForm({ ...form, images: [...form.images, ''] });
  const removeImageField = (idx: number) => setForm({ ...form, images: form.images.filter((_, i) => i !== idx) });
  const updateImageField = (idx: number, val: string) => {
    const updated = [...form.images];
    updated[idx] = val;
    setForm({ ...form, images: updated });
  };
  const addVideoField = () => setForm({ ...form, videos: [...form.videos, ''] });
  const removeVideoField = (idx: number) => setForm({ ...form, videos: form.videos.filter((_, i) => i !== idx) });
  const updateVideoField = (idx: number, val: string) => {
    const updated = [...form.videos];
    updated[idx] = val;
    setForm({ ...form, videos: updated });
  };

  const handleAddProduct = () => {
    if (!validateForm()) return;
    const selectedCat = categories.find(c => c.id === form.category);
    const validImages = form.images.filter(img => img.trim() !== '');
    const newProduct: Product = {
      id: 'p' + Date.now(),
      name: form.name.trim(),
      slug: form.name.trim().toLowerCase().replace(/\s+/g, '-'),
      description: form.description.trim() || 'New product added by seller',
      price: Number(form.price),
      mrp: Number(form.mrp),
      images: validImages.length > 0 ? validImages : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=600&fit=crop'],
      categoryId: form.category,
      categoryName: selectedCat?.name || '',
      brand: form.brand.trim(),
      stock: Number(form.stock),
      sold: 0,
      rating: 0,
      reviewCount: 0,
      specifications: {},
      tags: [form.brand.trim().toLowerCase()],
      isFeatured: false,
      isTrending: false,
      isFlashDeal: false,
      sellerId: currentSellerId || 'unknown',
      videoUrl: form.videos.filter(v => v.trim() !== '').join(',') || undefined,
    };
    addProduct(newProduct);
    setForm(emptyForm);
    setFormErrors({});
    setShowAddForm(false);
    showToast('Product "' + newProduct.name + '" added successfully!');
  };

  const sellerProducts = currentSellerId ? products.filter(p => p.sellerId === currentSellerId) : [];
  const totalRevenue = sellerProducts.reduce((sum, p) => sum + p.price * p.sold, 0);
  const totalSold = sellerProducts.reduce((sum, p) => sum + p.sold, 0);
  const lowStock = sellerProducts.filter(p => p.stock < 20);
  const avgRating = sellerProducts.length > 0
    ? sellerProducts.reduce((sum, p) => sum + p.rating, 0) / sellerProducts.length
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {!isAuthenticated && (
        <div className="min-h-[60vh] flex flex-col items-center justify-center">
          <p className="text-lg font-semibold mb-2">Please login to access Seller Dashboard</p>
          <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { useStore.getState().setAuthMode('login'); useStore.getState().setShowAuthModal(true); }}>Login</Button>
        </div>
      )}
      {isAuthenticated && user && (user.role !== 'seller' && user.role !== 'admin') && (
        <div className="min-h-[60vh] flex flex-col items-center justify-center">
          <p className="text-lg font-semibold mb-2">Access Denied</p>
          <p className="text-sm text-muted-foreground mb-4">Only seller and admin accounts can access this dashboard</p>
          <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { useStore.getState().setAuthMode('register'); useStore.getState().setShowAuthModal(true); }}>Create Seller Account</Button>
        </div>
      )}
      {isAuthenticated && user && (user.role === 'seller' || user.role === 'admin') && (<>
    <Button variant="ghost" size="sm" onClick={goBack} className="mb-4 -ml-2">← Back</Button>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Seller Dashboard</h1>
          <p className="text-sm text-muted-foreground">{storeName} — Manage your products, orders, and sales</p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { setForm(emptyForm); setFormErrors({}); setShowAddForm(true); }}>
          <Plus className="h-4 w-4 mr-2" /> Add Product
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Revenue', value: `₹${(totalRevenue / 1000).toFixed(0)}K`, icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50', change: '+15.3%' },
          { label: 'Total Sold', value: totalSold.toLocaleString(), icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-50', change: '+8.1%' },
          { label: 'Products', value: sellerProducts.length.toString(), icon: Package, color: 'text-orange-600', bg: 'bg-orange-50', change: '+2' },
          { label: 'Avg Rating', value: avgRating.toFixed(1), icon: Star, color: 'text-amber-600', bg: 'bg-amber-50', change: '' },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className={`w-9 h-9 rounded-lg ${stat.bg} flex items-center justify-center`}>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </div>
                {stat.change && (
                  <span className="text-xs text-green-600 font-medium flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-0.5" /> {stat.change}
                  </span>
                )}
              </div>
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="products" className="space-y-6">
        <TabsList>
          <TabsTrigger value="products">My Products</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
        </TabsList>

        {/* Products */}
        <TabsContent value="products">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Product Inventory</CardTitle>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { setForm(emptyForm); setFormErrors({}); setShowAddForm(true); }}>
                <Plus className="h-4 w-4 mr-1" /> Add New
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {sellerProducts.map((product) => {
                  const stockPercent = Math.min(100, (product.stock / 100) * 100);
                  const isEditing = editingId === product.id;
                  return (
                    <div key={product.id} className={"flex items-center gap-4 p-3 rounded-lg border transition-colors " + (isEditing ? "bg-emerald-50 border-emerald-300" : "hover:bg-gray-50")}>
                      <div className="w-14 h-14 rounded-lg overflow-hidden bg-gray-50 shrink-0">
                        <img src={product.images[0]} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-sm truncate">{product.name}</p>
                          {product.stock < 20 && <Badge className="bg-red-100 text-red-700 text-[10px]">Low Stock</Badge>}
                        </div>
                        <p className="text-xs text-muted-foreground">{product.brand} • {product.categoryName}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-sm font-semibold">₹{product.price.toLocaleString()}</span>
                          <span className="text-xs text-muted-foreground">Sold: {product.sold}</span>
                        </div>
                      </div>

                      {/* Stock - Inline Edit */}
                      <div className="w-28 sm:w-32 shrink-0">
                        {isEditing ? (
                          <Input
                            type="number"
                            min={0}
                            value={editStock}
                            onChange={(e) => setEditStock(Math.max(0, parseInt(e.target.value) || 0))}
                            className="h-8 text-sm"
                            autoFocus
                            onKeyDown={(e) => { if (e.key === 'Enter') saveStock(); if (e.key === 'Escape') cancelEdit(); }}
                          />
                        ) : (
                          <div>
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span className="text-muted-foreground">Stock</span>
                              <span className="font-medium">{product.stock}</span>
                            </div>
                            <Progress value={stockPercent} className="h-1.5" />
                          </div>
                        )}
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="View Product" onClick={() => goToProduct(product.id)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        {isEditing ? (
                          <>
                            <Button size="icon" className="h-8 w-8 bg-emerald-600 hover:bg-emerald-700" title="Save Stock" onClick={saveStock}>
                              <Check className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8" title="Cancel" onClick={cancelEdit}>
                              <X className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <Button variant="ghost" size="icon" className="h-8 w-8" title="Edit Stock" onClick={() => startEditStock(product.id, product.stock)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              {sellerProducts.length === 0 && (
                <div className="text-center py-8">
                  <Package className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
                  <p className="text-muted-foreground mb-3">No products yet</p>
                  <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setShowAddForm(true)}>
                    <Plus className="h-4 w-4 mr-1" /> Add Your First Product
                  </Button>
                </div>
              )}
              {lowStock.length > 0 && (
                <div className="mt-4 p-3 bg-orange-50 rounded-lg">
                  <p className="text-sm text-orange-700 font-medium">⚠️ {lowStock.length} product(s) running low on stock</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-emerald-600" /> Monthly Sales
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                      <Tooltip formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Sales']} />
                      <Bar dataKey="sales" fill="#059669" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Top Products</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sellerProducts
                    .sort((a, b) => b.sold - a.sold)
                    .slice(0, 5)
                    .map((product, idx) => (
                      <div key={product.id} className="flex items-center gap-3">
                        <span className="text-sm font-bold text-muted-foreground w-6">#{idx + 1}</span>
                        <div className="w-10 h-10 rounded-lg overflow-hidden bg-gray-50 shrink-0">
                          <img src={product.images[0]} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{product.name}</p>
                          <p className="text-xs text-muted-foreground">{product.sold} units sold</p>
                        </div>
                        <p className="text-sm font-semibold">₹{(product.price * product.sold).toLocaleString()}</p>
                      </div>
                    ))}
                  {sellerProducts.length === 0 && <p className="text-center text-muted-foreground py-8">No products to show</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Orders */}
        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No orders yet</p>
              ) : (
                <div className="space-y-3">
                  {orders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-3 rounded-lg border">
                      <div>
                        <p className="font-medium text-sm">Order #{order.id}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(order.createdAt).toLocaleDateString()} • {order.items.length} items
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-sm">₹{order.totalAmount.toLocaleString()}</p>
                        <Badge variant="secondary" className="text-[10px]">{order.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Product Modal */}
      {showAddForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowAddForm(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold">Add New Product</h2>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowAddForm(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Product Name *</label>
                <Input placeholder="Enter product name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                {formErrors.name && <p className="text-xs text-red-500 mt-1">{formErrors.name}</p>}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium mb-1 block">Selling Price (₹) *</label>
                  <Input type="number" placeholder="0" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
                  {formErrors.price && <p className="text-xs text-red-500 mt-1">{formErrors.price}</p>}
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">MRP (₹) *</label>
                  <Input type="number" placeholder="0" value={form.mrp} onChange={(e) => setForm({ ...form, mrp: e.target.value })} />
                  {formErrors.mrp && <p className="text-xs text-red-500 mt-1">{formErrors.mrp}</p>}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium mb-1 block">Stock Quantity *</label>
                  <Input type="number" placeholder="0" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
                  {formErrors.stock && <p className="text-xs text-red-500 mt-1">{formErrors.stock}</p>}
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Category *</label>
                  <select
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                  >
                    <option value="">Select category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                  {formErrors.category && <p className="text-xs text-red-500 mt-1">{formErrors.category}</p>}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Brand *</label>
                <Input placeholder="Enter brand name" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
                {formErrors.brand && <p className="text-xs text-red-500 mt-1">{formErrors.brand}</p>}
              </div>
              {/* Multiple Image URLs */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-sm font-medium">Product Images</label>
                  <button type="button" onClick={addImageField} className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                    <Plus className="h-3 w-3" /> Add Image
                  </button>
                </div>
                <div className="space-y-2">
                  {form.images.map((img, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                        {img.trim() ? (
                          <img src={img} alt="" className="w-full h-full rounded-lg object-cover" />
                        ) : (
                          <ImageIcon className="h-4 w-4 text-gray-400" />
                        )}
                      </div>
                      <Input
                        placeholder={"Image URL " + (idx + 1)}
                        value={img}
                        onChange={(e) => updateImageField(idx, e.target.value)}
                        className="flex-1 h-9"
                      />
                      {form.images.length > 1 && (
                        <button type="button" onClick={() => removeImageField(idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors shrink-0">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Add multiple product images for better display</p>
              </div>
              {/* Multiple Video Links */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-sm font-medium flex items-center gap-1.5">
                    <Video className="h-3.5 w-3.5" /> Product Videos
                  </label>
                  <button type="button" onClick={addVideoField} className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                    <Plus className="h-3 w-3" /> Add Video
                  </button>
                </div>
                <div className="space-y-2">
                  {form.videos.map((vid, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                        <Video className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        placeholder={"Video URL " + (idx + 1) + " (YouTube, etc.)"}
                        value={vid}
                        onChange={(e) => updateVideoField(idx, e.target.value)}
                        className="flex-1 h-9"
                      />
                      {form.videos.length > 1 && (
                        <button type="button" onClick={() => removeVideoField(idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors shrink-0">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Optional: Add multiple YouTube or video links for product demo</p>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Description</label>
                <textarea
                  className="flex min-h-[80px] w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none"
                  placeholder="Enter product description"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>
              <div className="flex gap-3 pt-2">
                <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700" onClick={handleAddProduct}>
                  <Check className="h-4 w-4 mr-2" /> Save Product
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setShowAddForm(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toastVisible && (
        <div className="fixed bottom-6 right-6 z-[60] bg-gray-900 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-2" style={{ minWidth: '250px' }}>
          <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
            <Check className="h-3.5 w-3.5 text-white" />
          </div>
          <span className="text-sm font-medium flex-1">{toastMsg}</span>
          <button onClick={() => setToastVisible(false)} className="text-gray-400 hover:text-white shrink-0 ml-2">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      </>)}
    </div>
  );
}
