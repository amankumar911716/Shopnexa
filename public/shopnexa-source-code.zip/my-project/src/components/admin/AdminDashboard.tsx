'use client';

import { useStore } from '@/store/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import {
  DollarSign, Package, Users, ShoppingBag, TrendingUp, ArrowUpRight,
  ArrowDownRight, Eye, Edit, Trash2, Activity, Plus, X, Check, Search, Video, ImageIcon
} from 'lucide-react';
import { useState, useMemo } from 'react';
import { Area, AreaChart, Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import type { Product } from '@/types';

const revenueData = [
  { month: 'Jan', revenue: 420000, orders: 1200 },
  { month: 'Feb', revenue: 380000, orders: 1050 },
  { month: 'Mar', revenue: 510000, orders: 1400 },
  { month: 'Apr', revenue: 460000, orders: 1280 },
  { month: 'May', revenue: 590000, orders: 1650 },
  { month: 'Jun', revenue: 620000, orders: 1780 },
  { month: 'Jul', revenue: 710000, orders: 2050 },
  { month: 'Aug', revenue: 680000, orders: 1920 },
  { month: 'Sep', revenue: 750000, orders: 2180 },
  { month: 'Oct', revenue: 820000, orders: 2400 },
  { month: 'Nov', revenue: 950000, orders: 2800 },
  { month: 'Dec', revenue: 1100000, orders: 3200 },
];

const categoryData = [
  { name: 'Electronics', value: 42, color: '#059669' },
  { name: 'Fashion', value: 28, color: '#d97706' },
  { name: 'Home', value: 15, color: '#0891b2' },
  { name: 'Sports', value: 8, color: '#7c3aed' },
  { name: 'Others', value: 7, color: '#64748b' },
];

export function AdminDashboard() {
  const { products, orders, goBack, goToProduct, categories } = useStore();

  // Edit dialog state
  const [editOpen, setEditOpen] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [editForm, setEditForm] = useState({ name: '', price: '', mrp: '', stock: '', images: ['' as string], videos: ['' as string], description: '' });

  // Add dialog state
  const [addOpen, setAddOpen] = useState(false);
  const [addForm, setAddForm] = useState({ name: '', brand: '', price: '', mrp: '', stock: '', category: '', description: '', images: ['' as string], videos: ['' as string] });

  // Delete confirm
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);

  // Toast
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  // Product search
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = useMemo(() => {
    if (!searchQuery.trim()) return products;
    const q = searchQuery.toLowerCase();
    return products.filter(p => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q));
  }, [products, searchQuery]);

  // Open Edit dialog
  const openEdit = (product: Product) => {
    setEditProduct(product);
    setEditForm({
      name: product.name,
      price: String(product.price),
      mrp: String(product.mrp),
      stock: String(product.stock),
      images: product.images.length > 0 ? product.images : [''],
      videos: product.videoUrl ? product.videoUrl.split(',').filter(v => v.trim()) : [''],
      description: product.description || '',
    });
    setEditOpen(true);
  };

  // Save Edit
  const saveEdit = () => {
    if (!editProduct || !editForm.name.trim()) return;
    showToast('Product "' + editForm.name + '" updated successfully!');
    setEditOpen(false);
  };

  // Open Delete confirm
  const openDelete = (product: Product) => {
    setDeleteTarget(product);
    setDeleteOpen(true);
  };

  // Open Add dialog
  const openAdd = () => {
    setAddForm({ name: '', brand: '', price: '', mrp: '', stock: '', category: categories[0]?.id || '', description: '', images: [''], videos: [''] });
    setAddOpen(true);
  };

  // Image helpers
  const addImageField = (formKey: 'addForm' | 'editForm') => {
    const form = formKey === 'addForm' ? addForm : editForm;
    const setter = formKey === 'addForm' ? setAddForm : setEditForm;
    setter({ ...form, images: [...form.images, ''] });
  };
  const removeImageField = (formKey: 'addForm' | 'editForm', idx: number) => {
    const form = formKey === 'addForm' ? addForm : editForm;
    const setter = formKey === 'addForm' ? setAddForm : setEditForm;
    if (form.images.length <= 1) return;
    setter({ ...form, images: form.images.filter((_, i) => i !== idx) });
  };
  const updateImageField = (formKey: 'addForm' | 'editForm', idx: number, val: string) => {
    const form = formKey === 'addForm' ? addForm : editForm;
    const setter = formKey === 'addForm' ? setAddForm : setEditForm;
    const updated = [...form.images];
    updated[idx] = val;
    setter({ ...form, images: updated });
  };
  const addVideoField = (formKey: 'addForm' | 'editForm') => {
    const form = formKey === 'addForm' ? addForm : editForm;
    const setter = formKey === 'addForm' ? setAddForm : setEditForm;
    setter({ ...form, videos: [...form.videos, ''] });
  };
  const removeVideoField = (formKey: 'addForm' | 'editForm', idx: number) => {
    const form = formKey === 'addForm' ? addForm : editForm;
    const setter = formKey === 'addForm' ? setAddForm : setEditForm;
    if (form.videos.length <= 1) return;
    setter({ ...form, videos: form.videos.filter((_, i) => i !== idx) });
  };
  const updateVideoField = (formKey: 'addForm' | 'editForm', idx: number, val: string) => {
    const form = formKey === 'addForm' ? addForm : editForm;
    const setter = formKey === 'addForm' ? setAddForm : setEditForm;
    const updated = [...form.videos];
    updated[idx] = val;
    setter({ ...form, videos: updated });
  };

  // Save Add
  const saveAdd = () => {
    if (!addForm.name.trim() || !addForm.price.trim()) return;
    showToast('Product "' + addForm.name + '" added successfully!');
    setAddOpen(false);
  };

  const stats = [
    { label: 'Total Revenue', value: '₹7,89,000', change: '+12.5%', up: true, icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Total Orders', value: '2,847', change: '+8.2%', up: true, icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Total Products', value: products.length.toString(), change: '+3', up: true, icon: Package, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Active Users', value: '12,456', change: '-2.1%', up: false, icon: Users, color: 'text-purple-600', bg: 'bg-purple-50' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 relative">
      {/* Toast notification */}
      {toast && (
        <div className="fixed top-20 right-4 z-[100] bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2 animate-in slide-in-from-right">
          <Check className="h-4 w-4" />
          <span className="text-sm font-medium">{toast}</span>
        </div>
      )}

      <Button variant="ghost" size="sm" onClick={goBack} className="mb-4 -ml-2">← Back</Button>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground">Welcome back! Here&apos;s what&apos;s happening with your store.</p>
        </div>
        <Badge className="bg-emerald-100 text-emerald-700">Admin</Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((stat) => (
          <Card key={stat.label} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <span className={`flex items-center text-xs font-medium ${stat.up ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-emerald-600" /> Revenue Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={revenueData}>
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#059669" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₹${(v / 100000).toFixed(0)}L`} />
                      <Tooltip formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Revenue']} />
                      <Area type="monotone" dataKey="revenue" stroke="#059669" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Sales by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={categoryData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={5} dataKey="value">
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2 mt-2">
                  {categoryData.map((cat) => (
                    <div key={cat.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }} />
                        <span>{cat.name}</span>
                      </div>
                      <span className="font-medium">{cat.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4 text-blue-600" /> Monthly Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="orders" fill="#0891b2" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Products */}
        <TabsContent value="products">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Product Management ({products.length})</CardTitle>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={openAdd}>
                <Plus className="h-4 w-4 mr-1" /> Add Product
              </Button>
            </CardHeader>
            <CardContent>
              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search products..." className="pl-9" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-white">
                    <tr className="border-b">
                      <th className="text-left py-3 font-medium text-muted-foreground">Product</th>
                      <th className="text-left py-3 font-medium text-muted-foreground hidden md:table-cell">Category</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Price</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Stock</th>
                      <th className="text-right py-3 font-medium text-muted-foreground hidden sm:table-cell">Sold</th>
                      <th className="text-center py-3 font-medium text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProducts.length === 0 ? (
                      <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">No products found</td></tr>
                    ) : (
                      filteredProducts.map((product) => (
                        <tr key={product.id} className="border-b hover:bg-gray-50">
                          <td className="py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                                <img src={product.images[0]} alt="" className="w-full h-full object-cover" />
                              </div>
                              <div>
                                <p className="font-medium truncate max-w-[180px]">{product.name}</p>
                                <p className="text-xs text-muted-foreground">{product.brand}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 text-muted-foreground hidden md:table-cell">{product.categoryName}</td>
                          <td className="py-3 text-right font-medium">₹{product.price.toLocaleString()}</td>
                          <td className="py-3 text-right">
                            <span className={product.stock < 20 ? 'text-red-600 font-medium' : ''}>{product.stock}</span>
                          </td>
                          <td className="py-3 text-right hidden sm:table-cell">{product.sold.toLocaleString()}</td>
                          <td className="py-3">
                            <div className="flex items-center justify-center gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-emerald-50" title="View" onClick={() => goToProduct(product.id)}><Eye className="h-4 w-4" /></Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-blue-50" title="Edit" onClick={() => openEdit(product)}><Edit className="h-4 w-4" /></Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-red-50" title="Delete" onClick={() => openDelete(product)}><Trash2 className="h-4 w-4" /></Button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders */}
        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No orders yet</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 font-medium text-muted-foreground">Order ID</th>
                        <th className="text-left py-3 font-medium text-muted-foreground">Date</th>
                        <th className="text-right py-3 font-medium text-muted-foreground">Items</th>
                        <th className="text-right py-3 font-medium text-muted-foreground">Total</th>
                        <th className="text-center py-3 font-medium text-muted-foreground">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => (
                        <tr key={order.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 font-medium">#{order.id}</td>
                          <td className="py-3 text-muted-foreground">{new Date(order.createdAt).toLocaleDateString()}</td>
                          <td className="py-3 text-right">{order.items.length}</td>
                          <td className="py-3 text-right font-medium">₹{order.totalAmount.toLocaleString()}</td>
                          <td className="py-3 text-center">
                            <Badge variant={order.status === 'delivered' ? 'default' : order.status === 'cancelled' ? 'destructive' : 'secondary'}>{order.status}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users */}
        <TabsContent value="users">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <Card><CardContent className="p-4 text-center"><Users className="h-8 w-8 mx-auto text-blue-600 mb-2" /><p className="text-2xl font-bold">12,456</p><p className="text-sm text-muted-foreground">Total Users</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><Package className="h-8 w-8 mx-auto text-emerald-600 mb-2" /><p className="text-2xl font-bold">156</p><p className="text-sm text-muted-foreground">Sellers</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><Activity className="h-8 w-8 mx-auto text-purple-600 mb-2" /><p className="text-2xl font-bold">3,420</p><p className="text-sm text-muted-foreground">Active Today</p></CardContent></Card>
          </div>
          <Card>
            <CardHeader><CardTitle className="text-base">Recent Users</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: 'Rahul Sharma', email: 'rahul@email.com', role: 'customer', joined: '2 days ago' },
                  { name: 'Priya Patel', email: 'priya@email.com', role: 'seller', joined: '5 days ago' },
                  { name: 'Amit Kumar', email: 'amit@email.com', role: 'customer', joined: '1 week ago' },
                  { name: 'TechStore', email: 'tech@store.com', role: 'seller', joined: '1 week ago' },
                  { name: 'Sneha Reddy', email: 'sneha@email.com', role: 'customer', joined: '2 weeks ago' },
                ].map((u) => (
                  <div key={u.email} className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center"><span className="text-emerald-700 text-xs font-semibold">{u.name.charAt(0)}</span></div>
                      <div><p className="text-sm font-medium">{u.name}</p><p className="text-xs text-muted-foreground">{u.email}</p></div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary" className="text-xs">{u.role}</Badge>
                      <span className="text-xs text-muted-foreground">{u.joined}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Product Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Product</DialogTitle>
            <DialogDescription>Update product details below</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Product Name</Label>
              <Input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Selling Price (₹)</Label>
                <Input type="number" value={editForm.price} onChange={(e) => setEditForm({ ...editForm, price: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>MRP (₹)</Label>
                <Input type="number" value={editForm.mrp} onChange={(e) => setEditForm({ ...editForm, mrp: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <Label>Stock Quantity</Label>
              <Input type="number" value={editForm.stock} onChange={(e) => setEditForm({ ...editForm, stock: e.target.value })} className="mt-1" />
            </div>
            {/* Multiple Images */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label>Product Images</Label>
                <button type="button" onClick={() => addImageField('editForm')} className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                  <Plus className="h-3 w-3" /> Add Image
                </button>
              </div>
              <div className="space-y-2">
                {editForm.images.map((img, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                      {img.trim() ? (
                        <img src={img} alt="" className="w-full h-full rounded-lg object-cover" />
                      ) : (
                        <ImageIcon className="h-4 w-4 text-gray-400" />
                      )}
                    </div>
                    <Input placeholder={"Image URL " + (idx + 1)} value={img} onChange={(e) => updateImageField('editForm', idx, e.target.value)} className="flex-1 h-9" />
                    {editForm.images.length > 1 && (
                      <button type="button" onClick={() => removeImageField('editForm', idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors shrink-0">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            {/* Video Links */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="flex items-center gap-1.5"><Video className="h-3.5 w-3.5" /> Video Links</Label>
                <button type="button" onClick={() => addVideoField('editForm')} className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                  <Plus className="h-3 w-3" /> Add Video
                </button>
              </div>
              <div className="space-y-2">
                {editForm.videos.map((vid, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                      <Video className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input placeholder={"Video URL " + (idx + 1) + " (YouTube, etc.)"} value={vid} onChange={(e) => updateVideoField('editForm', idx, e.target.value)} className="flex-1 h-9" />
                    {editForm.videos.length > 1 && (
                      <button type="button" onClick={() => removeVideoField('editForm', idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors shrink-0">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label>Description</Label>
              <textarea className="flex min-h-[70px] w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none mt-1" value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Product Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Product</DialogTitle>
            <DialogDescription>Fill in the details to add a new product</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Product Name *</Label>
              <Input placeholder="Enter product name" value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label>Brand *</Label>
              <Input placeholder="Enter brand name" value={addForm.brand} onChange={(e) => setAddForm({ ...addForm, brand: e.target.value })} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Selling Price (₹) *</Label>
                <Input type="number" placeholder="0" value={addForm.price} onChange={(e) => setAddForm({ ...addForm, price: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>MRP (₹) *</Label>
                <Input type="number" placeholder="0" value={addForm.mrp} onChange={(e) => setAddForm({ ...addForm, mrp: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Stock Quantity *</Label>
                <Input type="number" placeholder="0" value={addForm.stock} onChange={(e) => setAddForm({ ...addForm, stock: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Category *</Label>
                <select
                  value={addForm.category}
                  onChange={(e) => setAddForm({ ...addForm, category: e.target.value })}
                  className="mt-1 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
            </div>
            {/* Multiple Images */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label>Product Images</Label>
                <button type="button" onClick={() => addImageField('addForm')} className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                  <Plus className="h-3 w-3" /> Add Image
                </button>
              </div>
              <div className="space-y-2">
                {addForm.images.map((img, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                      {img.trim() ? (
                        <img src={img} alt="" className="w-full h-full rounded-lg object-cover" />
                      ) : (
                        <ImageIcon className="h-4 w-4 text-gray-400" />
                      )}
                    </div>
                    <Input placeholder={"Image URL " + (idx + 1)} value={img} onChange={(e) => updateImageField('addForm', idx, e.target.value)} className="flex-1 h-9" />
                    {addForm.images.length > 1 && (
                      <button type="button" onClick={() => removeImageField('addForm', idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors shrink-0">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Add multiple product images for better display</p>
            </div>
            {/* Video Links */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="flex items-center gap-1.5"><Video className="h-3.5 w-3.5" /> Video Links</Label>
                <button type="button" onClick={() => addVideoField('addForm')} className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                  <Plus className="h-3 w-3" /> Add Video
                </button>
              </div>
              <div className="space-y-2">
                {addForm.videos.map((vid, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                      <Video className="h-4 w-4 text-gray-400" />
                    </div>
                    <Input placeholder={"Video URL " + (idx + 1) + " (YouTube, etc.)"} value={vid} onChange={(e) => updateVideoField('addForm', idx, e.target.value)} className="flex-1 h-9" />
                    {addForm.videos.length > 1 && (
                      <button type="button" onClick={() => removeVideoField('addForm', idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors shrink-0">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Optional: Add multiple YouTube or video links for product demo</p>
            </div>
            <div>
              <Label>Description</Label>
              <textarea className="flex min-h-[70px] w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none mt-1" placeholder="Enter product description" value={addForm.description} onChange={(e) => setAddForm({ ...addForm, description: e.target.value })} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveAdd}>Add Product</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete Product</DialogTitle>
            <DialogDescription>Are you sure you want to delete &ldquo;{deleteTarget?.name}&rdquo;? This action cannot be undone.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { showToast('Product "' + deleteTarget?.name + '" deleted!'); setDeleteOpen(false); }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
